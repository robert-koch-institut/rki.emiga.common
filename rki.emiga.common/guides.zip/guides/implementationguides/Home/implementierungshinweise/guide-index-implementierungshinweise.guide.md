# {{page-title}}

## Inhaltsverzeichnis
Die folgenden Unterseiten beschreiben mögliche Implementierungsszenarien für die Umsetzung der EMIGA-Basismeldeinhalte.

{{index:children}}