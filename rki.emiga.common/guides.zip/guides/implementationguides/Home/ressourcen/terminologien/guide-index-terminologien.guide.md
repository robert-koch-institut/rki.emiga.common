# {{page-title}}

## Inhaltsverzeichnis

{{index:children}}

---

## Terminologien Überblick

In diesem Abschnitt werden die verwendeten **CodeSystems** und **ValueSets** beschrieben, die für die Standardisierung der Datenerfassung und -auswertung im ÖGD relevant sind. Sie sorgen für eine konsistente und einheitliche Kodierung der verschiedenen Konzepte.