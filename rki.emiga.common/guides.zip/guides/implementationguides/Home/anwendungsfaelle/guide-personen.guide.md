## {{page-title}}
Im Folgenden werden UML-Diagramme für Personen dargestellt, die die für dieses Modul relevanten Anwendungsfälle in komprimierter Form abbilden. Der Schwerpunkt liegt auf den zentralen Use Cases und den dafür erforderlichen Funktionen, um eine klare und gut nachvollziehbare Übersicht zu gewährleisten.

## Überblick
{{render:guides/implementationguides/PlantUML/PNGs/AffectedPersonBundle.png}}
{{render:guides/implementationguides/PlantUML/PNGs/PersonRelatedPersonOverview.png}}

## Betroffene Person
{{render:guides/implementationguides/PlantUML/PNGs/AffectedPerson.png}}

## Bezugsperson der betroffenen Person
{{render:guides/implementationguides/PlantUML/PNGs/AffectedPersonRelatedPerson.png}}