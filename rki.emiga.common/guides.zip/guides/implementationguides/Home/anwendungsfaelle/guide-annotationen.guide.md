## {{page-title}}
Im Folgenden werden UML-Diagramme für Annotationen dargestellt, die die für dieses Modul relevanten Anwendungsfälle in komprimierter Form abbilden. Der Schwerpunkt liegt auf den zentralen Use Cases und den dafür erforderlichen Funktionen, um eine klare und gut nachvollziehbare Übersicht zu gewährleisten.

## Überblick
{{render:guides/implementationguides/PlantUML/PNGs/AnnotationBundle.png}}

## Annotation
{{render:guides/implementationguides/PlantUML/PNGs/AnnotationCommunication.png}}